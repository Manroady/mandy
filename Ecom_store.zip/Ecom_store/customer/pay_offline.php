<center><!-- center Starts -->

<h1> Pay OffLine Using Method  </h1>

<p class="text-muted" >

If you have any questions, please feel free to <a href="../contact.php" >contact us,</a> our customer service center is working for you 24/7.

</p>

</center><!-- center Ends -->

<hr>


<div class="table-responsive" ><!-- table-responsive Starts -->

<table class="table table-bordered table-hover table-striped" ><!-- table table-bordered table-hover table-striped Starts -->

<thead><!-- thead Starts -->

<tr>

<th> Bank Account Details </th>

<th> Easy Paisa,UBL Omni,Mobi Cash Details: </th>

<th> Western Union Details: </th>

</tr>

</thead><!-- thead Ends -->

<tbody><!-- tbody Starts -->

<tr>

<td> Bank Name:ubl Account No:03333333 Branch Code:0342 Branch Name:Shadara Lahore	 </td>

<td> NIC#001234567 Mobile No:03334566931, Name:M.T.Ahmed </td>

<td> Full Name:M.T.Ahmed, Mobile No:03334566931, Name:M.T.Ahmed, Country:Pakistan, N.I.C No:001234567
</td>


</tr>

</tbody><!-- tbody Ends -->


</table><!-- table table-bordered table-hover table-striped Ends -->

</div><!-- table-responsive Ends -->